resource "aws_db_subnet_group" "capstone_db_subnet_group" {
  name = "capstone-db-subnet-group"
  subnet_ids = [
    aws_subnet.private_subnet_1.id,
    aws_subnet.private_subnet_2.id
  ]

  tags = {
    Name = "capstone-db-subnet-group"
  }
}

resource "aws_security_group" "rds_sg" {
  name        = "capstone-rds-sg"
  description = "Security group for RDS"
  vpc_id      = aws_vpc.capstone_vpc.id

  ingress {
    from_port       = 3306
    to_port         = 3306
    protocol        = "tcp"
    security_groups = [aws_security_group.ec2_sg.id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "capstone-rds-sg"
  }
}

resource "aws_db_instance" "capstone_rds" {
  identifier             = "capstone-rds"
  engine                 = "mysql"
  instance_class         = "db.t3.micro"
  allocated_storage      = 20
  username               = "admin"
  password               = "password123"
  db_subnet_group_name   = aws_db_subnet_group.capstone_db_subnet_group.name
  vpc_security_group_ids = [aws_security_group.rds_sg.id]
  publicly_accessible    = false
  skip_final_snapshot    = true

  tags = {
    Name = "capstone-rds"
  }
}