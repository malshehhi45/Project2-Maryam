output "vpc_id" {
  value = aws_vpc.capstone_vpc.id
}

output "alb_dns_name" {
  value = aws_lb.capstone_alb.dns_name
}

output "ec2_instance_1_id" {
  value = aws_instance.app_1.id
}

output "ec2_instance_2_id" {
  value = aws_instance.app_2.id
}

output "rds_endpoint" {
  value = aws_db_instance.capstone_rds.endpoint
}